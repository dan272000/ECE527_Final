import numpy as np
from scipy import ndimage
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import struct

def gaussian_kernel(size, sigma=1):
    size = int(size) // 2
    x, y = np.mgrid[-size:size+1, -size:size+1]
    normal = 1 / (2.0 * np.pi * sigma**2)
    g = np.exp(-((x**2 + y**2) / (2.0*sigma**2))) * normal
    return g

def import_image(filename, img_x, img_y):
    # # Import img from .bin
    with open(filename, 'rb') as binfile:
        contents = binfile.read()

    imported_img = np.zeros([img_x, img_y])
    for i in range(0, int(len(contents) / (4 * img_x))):
        for j in range(0, int(len(contents) / (4 * img_y))):
            imported_img[i, j] = struct.unpack('<I', contents[j * 4 + i * img_x * 4:j * 4 + i * img_x * 4 + 4])[0]

    return imported_img

def export_image(filename, img):
    # # Import img to .bin
    with open(filename, 'wb') as export:
        m, n = np.shape(img)
        for i in range(0, m):
            for j in range(0, n):
                # export.write(bytes.fromhex(hex(struct.unpack('<I', struct.pack('<f', img[i, j]))[0])[2:]))
                export.write(struct.pack('<f', img[i, j]))

# Open and display original image
# orig_img = mpimg.imread('test_image4.png')
#
# img = np.zeros([np.size(orig_img[:, 0, 0]), np.size(orig_img[0, :, 0])], np.float32)
# img[:, :] = orig_img[:, :, 0] * 299 / 1000 + orig_img[:, :, 1] * 587 / 1000 + orig_img[:, :, 2] * 114 / 1000
# img = img[120:270, 495:645]

# plt.figure(1)
# imgplot = plt.imshow(orig_img)
# plt.figure(2)
# imgplot2 = plt.imshow(img, cmap='gray')

# Export img to .bin
# export_image('lamp150x150_greyscale.bin', img)

# gk = gaussian_kernel(15, 2)
# # Export gaussian kernel to .bin
# export_image('gaussian.bin', gk)
#
imported_img1 = import_image('L1.BIN', 150, 150)
imported_img2 = import_image('LAMP_REF.BIN', 150, 150)
#
# plt.figure(2)
# imgplot1 = plt.imshow(imported_img1, cmap='gray')
# plt.figure(3)
# imgplot2 = plt.imshow(imported_img2, cmap='gray')

# plt.figure(3)
# imgplot2 = plt.imshow(imported_img2, cmap='gray')
plt.show()