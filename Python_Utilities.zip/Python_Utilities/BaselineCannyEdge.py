# Author: mjd17
# Baseline implementation of Canny edge detection in floating point

import numpy as np
from scipy import ndimage
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import struct


def import_image(filename, img_x, img_y):
    # # Import img from .bin
    with open(filename, 'rb') as binfile:
        contents = binfile.read()

    imported_img = np.zeros([img_x, img_y])
    for i in range(0, int(len(contents) / (4 * img_x))):
        for j in range(0, int(len(contents) / (4 * img_y))):
            imported_img[i, j] = struct.unpack('<I', contents[j * 4 + i * img_x * 4:j * 4 + i * img_x * 4 + 4])[0]

    return imported_img


def gaussian_kernel(size, sigma=1):
    size = int(size) // 2
    x, y = np.mgrid[-size:size+1, -size:size+1]
    normal = 1 / (2.0 * np.pi * sigma**2)
    g = np.exp(-((x**2 + y**2) / (2.0*sigma**2))) * normal
    return g


def gaussian_blur(img, gc):
    M, N = img.shape
    output = np.zeros((M, N), dtype=np.float32)
    for l in range(0,150):
        for k in range(0, 150):
            sum = 0
            for i in range(0, 15):
                for j in range(0, 15):
                    if l-i+7 >= 0 and k-j+7 >= 0 and k-j+7 < 150 and l-i+7 < 150:
                        sum += gc[i,j] * img[l-i+7, k-j+7]
                    else:
                        sum += 0
            output[l][k] = sum
    return output


def sobel_filter(img):
    Kx = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], np.float32)
    Ky = np.array([[1, 2, 1], [0, 0, 0], [-1, -2, -1]], np.float32)

    M, N = img.shape
    output = np.zeros((M, N), dtype=np.float32)
    output2 = np.zeros((M, N), dtype=np.float32)
    theta = np.zeros((M, N), dtype=np.float32)
    G = np.zeros((M, N), dtype=np.float32)

    for l in range(0,150):
        for k in range(0, 150):
            for i in range(0, 3):
                for j in range(0, 3):
                    if l-i+1 >= 0 and k-j+1 >= 0 and k-j+1 < 150 and l-i+1 < 150:
                        output[l][k] += Kx[i, j] * img[l-i+1, k-j+1]
                    else:
                        output[l][k] += 0

    for l in range(0,150):
        for k in range(0, 150):
            for i in range(0, 3):
                for j in range(0, 3):
                    if l-i+1 >= 0 and k-j+1 >=0 and k-j+1 < 150 and l-i+1 < 150:
                        output2[l][k] += Ky[i, j] * img[l-i+1, k-j+1]
                    else:
                        output2[l][k] += 0

    # G = np.hypot(output, output2)

    # G = G / G.max() * 255

    # theta = np.arctan2(output2, output) * 57.2958

    for l in range(0,150):
        for k in range(0, 150):
            theta[l][k] = np.arctan2(output2[l][k], output[l][k]) * 57.2958
            if theta[l][k] < 0:
                theta[l][k] += 180
    #
    max = 0
    # G = np.hypot(output, output2)
    for l in range(0,150):
        for k in range(0, 150):
            G[l][k] = (output[l][k] ** 2 + output2[l][k] ** 2) ** 0.5
            # if output[l][k] > output2[l][k]:
            #     G[l][k] = output[l][k] * 0.960433387 + output2[l][k] * 0.397824735
            # else:
            #     G[l][k] = output[l][k] * 0.397824735 + output2[l][k] * 0.960433387

            if G[l][k] > max:
                max = G[l][k]

    for l in range(0,150):
        for k in range(0, 150):
            G[l][k] = G[l][k] / max * 255

    return (G, theta)


def non_max_suppression(img, D):
    M, N = img.shape
    Z = np.zeros((M, N), dtype=np.float32)
    angle = D
    # angle = D * 180. / np.pi
    # angle[angle < 0] += 180

    for i in range(1, M - 1):
        for j in range(1, N - 1):
            try:
                q = 255
                r = 255

                # angle 0
                if (0 <= angle[i, j] < 22.5) or (157.5 <= angle[i, j] <= 180):
                    q = img[i, j + 1]
                    r = img[i, j - 1]
                # angle 45
                elif (22.5 <= angle[i, j] < 67.5):
                    q = img[i + 1, j - 1]
                    r = img[i - 1, j + 1]
                # angle 90
                elif (67.5 <= angle[i, j] < 112.5):
                    q = img[i + 1, j]
                    r = img[i - 1, j]
                # angle 135
                elif (112.5 <= angle[i, j] < 157.5):
                    q = img[i - 1, j - 1]
                    r = img[i + 1, j + 1]

                if (img[i, j] >= q) and (img[i, j] >= r):
                    Z[i, j] = img[i, j]
                else:
                    Z[i, j] = 0

            except IndexError as e:
                pass

    return Z


def threshold(img, lowThresholdRatio=0.1, highThresholdRatio=0.3):

    max = 0
    # G = np.hypot(output, output2)
    for l in range(0,150):
        for k in range(0, 150):
            if img[l][k] > max:
                max = img[l][k]

    highThreshold = max * highThresholdRatio
    lowThreshold = highThreshold * lowThresholdRatio

    M, N = img.shape
    res = np.zeros((M, N), dtype=np.int32)

    weak = np.int32(25)
    strong = np.int32(255)

    for l in range(0,150):
        for k in range(0, 150):
            if img[l][k] > highThreshold:
                res[l][k] = strong
            elif img[l][k] > lowThreshold:
                res[l][k] = weak
            else:
                res[l][k] = 0

    return (res, weak, strong)


def hysteresis(img, weak, strong=1):
    M, N = img.shape
    for i in range(1, M-1):
        for j in range(1, N-1):
            if (img[i,j] == weak) and (((img[i+1, j-1] == strong) or (img[i+1, j] == strong)
                                        or (img[i+1, j+1] == strong) or (img[i, j-1] == strong)
                                        or (img[i, j+1] == strong) or (img[i-1, j-1] == strong)
                                        or (img[i-1, j] == strong) or (img[i-1, j+1] == strong))):
                    img[i, j] = strong
            elif (img[i,j] == strong):
                    img[i, j] = strong
            else:
                    img[i, j] = 0

    return img

orig_img = mpimg.imread('test_image4.png')

# print(np.shape(orig_img))
# print(orig_img[0, 0, :])
img = np.zeros([np.size(orig_img[:, 0, 0]), np.size(orig_img[0, :, 0])], np.float32)
img[:, :] = orig_img[:, :, 0] * 299 / 1000 + orig_img[:, :, 1] * 587 / 1000 + orig_img[:, :, 2] * 114 / 1000

img = img[120:270, 495:645]

# Create gaussian Kernel
gc = gaussian_kernel(15, 2)
# Apply gaussian blur
img_blur = gaussian_blur(img, gc)

# Apply Sobel Filters
img_sobel = sobel_filter(img_blur)

# Apply Non-Maximum Suppression
img_nms = non_max_suppression(img_sobel[0], img_sobel[1])

# Apply thresholding
img_thresh = threshold(img_nms, 0.1, 0.3)
# img_thresh_int = threshold(img_nms_int, 0.05, 0.2)

# Apply Hysteresis
img_hys = hysteresis(img_thresh[0], img_thresh[1], img_thresh[2])

# errors = np.sum(np.logical_xor(img_hys, img_hys_int))
# print(errors)
# print(errors/np.size(img_hys))

# imported_img1 = import_image('LAMP_OP4.BIN', 150, 150)

plt.figure(1)
imgplot = plt.imshow(img_hys, cmap='gray')

plt.figure(2)
imgplot2 = plt.imshow(img, cmap='gray')
#
# plt.figure(3)
# imgplot3 = plt.imshow(orig_img)
#
plt.show()

