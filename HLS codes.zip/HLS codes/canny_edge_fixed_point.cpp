#include <string.h>
#include "hls_math.h"
#include "ap_fixed.h"
#include "ap_int.h"
typedef ap_fixed<16,12> fixed32;

#define FIXED_POINT_FRACTIONAL_BITS16 4



void read_image(
float image[150][150],
fixed32 image_c[150][150]
) {
	for(int i = 0; i < 150; i++){
		for(int j = 0; j < 150; j++){
			image_c[i][j] = (fixed32)(image[i][j]*(1<<FIXED_POINT_FRACTIONAL_BITS16));
		}
	}
}

void read_gaussian(
float gaussian_kernel[15][15],
fixed32 gaussian_kernel_c[15][15]
) {
	for(int i = 0; i < 150; i++){
			for(int j = 0; j < 150; j++){
				gaussian_kernel_c[i][j] = (fixed32)(gaussian_kernel[i][j]*(1<<FIXED_POINT_FRACTIONAL_BITS16));
			}
		}
}

void gaussian_blur(fixed32 image[150][150], fixed32 gaussian_kernel[15][15], fixed32 output_tmp[150][150])
{
	for(int l = 0; l < 150; l++)
	{
		for(int k = 0; k < 150; k++)
		{
			fixed32 sum = 0;
			for(int i = 0; i < 15; i++)
			{
				#pragma HLS pipeline
				for(int j = 0; j < 15; j++)
				{
					if(l-i+7 >= 0 && k-j+7 >= 0 && k-j+7 < 150 && l-i+7 < 150)
					{
						sum += gaussian_kernel[i][j] * image[l-i+7][k-j+7];
					}
					else
					{
						sum += 0;
					}
				}
			}
			output_tmp[l][k] = sum;
		}
	}
}

void sobel_filter(fixed32 image[150][150], fixed32 sobelx[3][3], fixed32 sobely[3][3], fixed32 output[150][150], fixed32 theta[150][150])
{

	fixed32 todeg = 57.2958;
	fixed32 oneradian = 180.0;
	fixed32 max = 0;

	for(int l = 0; l < 150; l++)
	{
		for(int k = 0; k < 150; k++)
		{
			fixed32 tmp1 = 0;
			fixed32 tmp2 = 0;
			for(int i = 0; i < 3; i++)
			{
				for(int j = 0; j < 3; j++)
				{
					if(l-i+1 >= 0 && k-j+1 >= 0 && k-j+1 < 150 && k-j+1 < 150)
					{
						tmp1 += sobelx[i][j] * image[l-i+1][k-j+1];
						tmp2 += sobely[i][j] * image[l-i+1][k-j+1];
					}
					else
					{
						tmp1 += 0;
						tmp2 += 0;
					}

				}
			}

			theta[l][k] = hls::atan2(tmp2, tmp1) * todeg;
			if(theta[l][k] < 0)
			{
				theta[l][k] += oneradian;
			}
			fixed32 calc = tmp1 * tmp1 + tmp2 * tmp2;
			output[l][k] = hls::sqrt(calc);
			if (output[l][k] > max)
			{
				max = output[l][k];
			}

		}
	}

	// Normalize to 255
	for(int l = 0; l < 150; l++)
	{
		for(int k = 0; k < 150; k++)
		{
			output[l][k] = output[l][k] / max * (fixed32)255;
		}
	}
}

void non_max_suppression(fixed32 image[150][150], fixed32 theta[150][150], fixed32 output[150][150])
{


	for(int l = 1; l < 149; l++)
		{
			for(int k = 1; k < 149; k++)
			{
				fixed32 q = 255;
				fixed32 r = 255;
				if((0 <= theta[l][k] && theta[l][k] < 22.5) || (157.5 <= theta[l][k] && theta[l][k] <= 180))
				{
					q = image[l][k+1];
					r = image[l][k-1];
				}
				else if(22.5 <= theta[l][k] && theta[l][k] < 67.5)
				{
					q = image[l+1][k-1];
					r = image[l-1][k+1];
				}
				else if(67.5 <= theta[l][k] && theta[l][k] < 112.5)
				{
					q = image[l+1][k];
					r = image[l-1][k];
				}
				else  //(112.5 <= theta[l][k] && theta[l][k] < 157.5)
				{
					q = image[l-1][k-1];
					r = image[l+1][k+1];
				}

				if (image[l][k] >= q && image[l][k] >= r)
				{
					output[l][k] = image[l][k];
				}
				else
				{
					output[l][k] = 0;
				}
			}
		}

}

void threshold(fixed32 img[150][150], fixed32 low_ratio, fixed32 high_ratio, int result_int[150][150], int weak, int strong)
{


	// Find image max
	fixed32 max = 0;
	for(int l = 0; l < 150; l++)
	{
		for(int k = 0; k < 150; k++)
		{
			if (img[l][k] > max)
			{
				max = img[l][k];
			}
		}
	}

	fixed32 high_thresh = max * high_ratio;
	fixed32 low_thresh = high_thresh * low_ratio;

	for(int l = 0; l < 150; l++)
	{
		for(int k = 0; k < 150; k++)
		{
			if(img[l][k] > high_thresh)
			{
				result_int[l][k] = strong;
			}
			else if((img[l][k] > low_thresh))
			{
				result_int[l][k] = weak;
			}
			else
			{
				result_int[l][k] = 0;
			}
		}
	}

}

void hysteresis(int image[150][150], int weak, int strong)
{
	for(int l = 1; l < 149; l++)
	{
		for(int k = 1; k < 149; k++)
		{
			if(image[l][k] == weak && (image[l-1][k+1] == strong || image[l][k+1] == strong || image[l+1][k+1] == strong
									  || image[l+1][k] == strong || image[l+1][k-1] == strong || image[l][k-1] == strong
									  || image[l-1][k-1] == strong || image[l-1][k] == strong))
			{
				image[l][k] = strong;
			}
			else if (image[l][k] == strong)
			{
				image[l][k] = strong;
			}
			else
			{
				image[l][k] = 0;
			}
		}
	}
}

void canny_accelerator(float image[150][150], float gaussian_kernel[15][15], int result[150][150])
{
	#pragma HLS INTERFACE s_axilite register port=return bundle=CTL

	#pragma HLS INTERFACE m_axi depth=64 port=image offset=slave bundle=IMAGE
	#pragma HLS INTERFACE m_axi depth=64 port=gaussian_kernel offset=slave bundle=GAUSS_KERNEL
	#pragma HLS INTERFACE m_axi depth=64 port=result offset=slave bundle=RESULT

	fixed32 tmp1[150][150] = {0};
	fixed32 tmp2[150][150] = {0};
	fixed32 tmp3[150][150] = {0};
	fixed32 tmp4[150][150] = {0};

//	int pre_result[150][150];

	fixed32 high_ratio = 0.3;
	fixed32 low_ratio = 0.1;
	int weak = 25;
	int strong = 255;

	fixed32 gaussian_kernel_c[15][15];
	fixed32 sobelx[3][3] =
	{
			{-1, 0, 1},
			{-2, 0, 2},
			{-1, 0, 1}
	};
	fixed32 sobely[3][3] =
	{
			{ 1,  2,  1},
			{ 0,  0,  0},
			{-1, -2, -1}
	};

	read_image(image, tmp1);
	read_gaussian(gaussian_kernel, gaussian_kernel_c);

//	#pragma HLS array_partition variable = ouput_pool4 cyclic dim = 1 factor = 16
//	#pragma HLS array_partition variable = conv5_weights_b cyclic dim = 2 factor = 16

	gaussian_blur(tmp1, gaussian_kernel_c, tmp2);

	// sobel_filter(float image[150][150], float sobelx[3][3], float sobely[3][3], float output[150][150], float theta[150][150])
	sobel_filter(tmp2, sobelx, sobely, tmp3, tmp1);

	// non_max_suppression(float image[150][150], float theta[150][150], float output[150][150])
	non_max_suppression(tmp3, tmp1, tmp4);

	threshold(tmp4, low_ratio, high_ratio, result, weak, strong);

	hysteresis(result, weak, strong);

}


